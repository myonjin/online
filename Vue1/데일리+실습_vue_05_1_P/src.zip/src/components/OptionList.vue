<template>
  <div>
    <h1>3. 옵션을 고르세요.</h1>
    <ul class="option-list">
    </ul>
  </div>
</template>

<script>

export default {
  name: 'OptionList',
  components: {
  },
  computed: {
    optionList: function () {
    },
  },
  methods: {
    increase: function () {
    },
    decrease: function () {
    },
  },
}
</script>

<style>
</style>